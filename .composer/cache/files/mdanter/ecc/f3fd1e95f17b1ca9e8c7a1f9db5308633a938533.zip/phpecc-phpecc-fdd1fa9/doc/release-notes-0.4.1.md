# v0.4.1 release notes

v0.4.1 is a minor release for the library. 

   - Support paragonie/random_compat versions ^1|^2 for wider compatibility

## Notable changes:

This overview includes changes that affect behaviour, not code moves, refactors, tests, etc.

### New:

   - [(#178)](https://github.com/phpecc/phpecc/pull/178) [7e217f9] Update composer.json to require paragonie/random_compat@"^1|^2"

## Credits

Thanks to everyone who directly contributed to this release:

 - Marc Kolly
