# v0.4.2 release notes

v0.4.2 is a minor release for the library. It addresses unintended behaviour in decHex, 
which should have rejected negative numbers. 

   - [(#182)](https://github.com/phpecc/phpecc/pull/182) [0ae116d] reject negative integers in intToString and decHex.

## Credits

Thanks to everyone who directly contributed to this release:

 - Ruben de Vries (@rubensayshi)
